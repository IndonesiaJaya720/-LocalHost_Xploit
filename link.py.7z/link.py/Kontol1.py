# Decompiled By RandiSr                     # Github : https://github.com/RANDIOLOY
# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.17 (default, ># [GCC 4.2.1 Compatible Android (5220042 ba>
# Embedded file name: <Ahmad_Riswanto>
import os
os.system('xdg-open https://wa.wizard.id/b18dd8')

