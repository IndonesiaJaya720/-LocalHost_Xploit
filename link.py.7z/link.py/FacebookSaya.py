import os
os.system('xdg-open https://www.facebook.com/jonathan.piter.71')

