import os
os.system('xdg-open mailto:jonathanhasudungan32@gmail.com')

